var Separator = "Separator";
var Message = "Message";
var Question = "Question";
var DashedSentence = "DashedSentence";
var AcceptabilityJudgment = "AcceptabilityJudgment";
var FlashSentence = "FlashSentence";
var VBox = "VBox";